import re
from flask import Flask, request, render_template, jsonify
from sintaxis import verificar_sintaxis_while  # Suponiendo que tienes una función similar para la sintaxis de while

app = Flask(__name__)

def analizador_lexico(codigo):
    tokens = []
    lineas = codigo.split('\n')
    for num_linea, linea in enumerate(lineas, start=1):
        # Eliminar comentarios y espacios en blanco al principio y al final de la línea
        linea = re.sub(r'\/\/.*|\/\*.*\*\/', '', linea).strip()

        # Encontrar tokens en la línea
        while linea:
            encontrado = False
            for patron, tipo in PATRONES.items():
                match = re.match(patron, linea)
                if match:
                    token = match.group(0)
                    # Si el tipo es Cadena, añadimos solo las comillas como token
                    if tipo == 'Cadena':
                        tokens.append((num_linea, 'Comillas', '"'))
                        contenido_comillas = re.search(r'".*?"', token).group(0)
                        tokens.append((num_linea, 'Identificador', contenido_comillas.strip('"')))
                        # Eliminamos el token completo (incluyendo comillas) antes de continuar
                        linea = linea[len(token):].strip()
                    # Si no, eliminamos las comillas antes de añadir el token
                    else:
                        # Si el token tiene comillas, las eliminamos antes de añadirlo
                        if '"' in token or "'" in token:
                            token = token.strip('"').strip("'")
                        tokens.append((num_linea, tipo, token))
                        linea = linea[len(token):].strip()
                    encontrado = True
                    break
            if not encontrado:
                # Si no se encontró un token válido, se ignora el carácter y se avanza
                linea = linea[1:].strip()

    return tokens

# Definir patrones de expresiones regulares para cada tipo de token
PATRONES = {
    r'\b(?:static|void|int|for|while)\b': 'Palabra reservada',
    r'\b[_a-zA-Z][_a-zA-Z0-9]*\b': 'Identificador',
    r'\b\(\)': 'Parentesis vacio',
    r'\(': 'Paréntesis Apertura',
    r'\)': 'Paréntesis Cierre',
    r'\[': 'Corchete Apertura',
    r'\]': 'Corchete Cierre',
    r'\{': 'Llave Apertura',
    r'\}': 'Llave Cierre',
    r';': 'Punto y Coma',
    r',': 'Coma',
    r'\".*?\"': 'Cadena',
    r'\+\+': 'Operador de incremento',
    r'--': 'Operador de decremento',
    r'\b\+{2}|-{2}\b': 'Operador de incremento/decremento',
    r'\b\+|-|\*|/|%|\+=|-=|\*=|/=|%=|==|!=|<|>|<=|>=\b': 'Operador',
    r'\b\d+\b': 'Número Entero'
}

@app.route('/', methods=['GET', 'POST'])
def analizar_codigo():
    resultado = ""
    if request.method == 'POST':
        codigo = request.form['codigo']
        tokens = analizador_lexico(codigo)
        for token in tokens:
            resultado += f"Línea {token[0]}:\t{token[1]}\t\t{token[2]}\n"
    return render_template('analizador.html', resultado=resultado)

@app.route('/analizar_sintacticamente', methods=['POST'])
def volver_analizar():
    codigo = request.form['codigo']
    mensaje = verificar_sintaxis_while(codigo)  # Llamar a la función de sintaxis de while
    return jsonify({'mensaje': mensaje})

if __name__ == '__main__':
    app.run(debug=True)

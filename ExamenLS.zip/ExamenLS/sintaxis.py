import re

def verificar_sintaxis_while(codigo):
    errores = []

    # Verificar si la palabra 'public class' está presente en el código
    if 'public class' not in codigo:
        errores.append("Error sintáctico: Falta la declaración de la clase 'public class'.")
    else:
        # Verificar si el método 'main' sigue el patrón esperado
        patron_main = r'public\s+static\s+void\s+main\s*\(\s*String\[\]\s+args\s*\)\s*\{.*?\}'
        if not re.search(patron_main, codigo, re.DOTALL):
            errores.append("Error sintáctico: El formato del método 'main' es incorrecto.")

        # Verificar si la sentencia 'System.out.println' está presente en el método 'main'
        if 'System.out.println' not in codigo:
            errores.append("Error sintáctico: Falta la sentencia 'System.out.println' dentro del método 'main'.")
        else:
            # Verificar la sintaxis de la sentencia 'System.out.println'
            patron_println = r'System\.out\.println\s*\(\s*".*?"\s*\);'
            if not re.search(patron_println, codigo):
                errores.append("Error sintáctico: La sintaxis de la sentencia 'System.out.println' es incorrecta.")

    # Verificar si los paréntesis, corchetes, comillas dobles y llaves están balanceados en todo el código
    if codigo.count('(') != codigo.count(')'):
        errores.append("Error sintáctico: Paréntesis no balanceados.")
    if codigo.count('[') != codigo.count(']'):
        errores.append("Error sintáctico: Corchetes no balanceados.")
    if codigo.count('"') % 2 != 0:
        errores.append("Error sintáctico: Comillas dobles no balanceadas.")
    if codigo.count('{') != codigo.count('}'):
        errores.append("Error sintáctico: Llaves no balanceadas.")

    if errores:
        return "\n".join(errores)
    else:
        return "La sintaxis es correcta."
